# Welcome to Keen - The Ultimate Multi-Demo Bootstrap Admin Theme

- To get started please open the [Documentation page](//keenthemes.com/keen/?page=docs). 

- To launch the default buildable package's demo templates you will need to install the build tools 
  and compile the theme(initially the assets are not compiled) by referring to the documentation.

- For any theme related questions please contact our [Theme Support](//keenthemes.com/theme-support/).

Happy coding with Keen!